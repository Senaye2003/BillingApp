package edu.uncc.assignment12;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverter;
import androidx.room.TypeConverters;

@Database(entities = {Bill.class}, version = 2)
@TypeConverters({Converters.class})
public abstract class BillDatabase extends RoomDatabase {
    public abstract BillDAO billDAO();
}
