package edu.uncc.assignment12;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface BillDAO {
    @Query("SELECT * FROM bill")
    List<Bill> getAll();

    @Insert
    void insertAll(Bill... bill);

    @Insert
    void insert(Bill bill);

    @Delete
    void deleteAll(List<Bill> bill);

    @Delete
    void delete(Bill bill);

    @Update
    public void updateBill(Bill bill);
}
